<ul class="minicart">
    <?php if($cart->count() > 0): ?>
        <div class="cart-contents">
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex align-items-start">
                    <div class="cart-img">
                        <a href="#"><img src="<?php echo e($item['image']); ?>" alt=""></a>
                    </div>
                    <div class="cart-content">
                        <h4><a href="#"><?php echo e($item['name']); ?></a></h4>
                        <div class="cart-price">
                            <span class="new">₺<?php echo e(number_format($item['price'], 2, ',', '.')); ?></span>
                            <span class="quantity"> x<?php echo e($item['quantity']); ?></span>
                        </div>
                    </div>
                    <div class="del-icon">
                        <a href="#" class="remove-from-cart"
                           data-id="<?php echo e(Auth::check() ? $item['product_id'] : $loop->index); ?>">
                            <i class="far fa-trash-alt"></i>
                        </a>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <li>
            <div class="total-price">
                <span class="f-left">Toplam:</span>
                <span class="f-right">₺<?php echo e(number_format($total, 2, ',', '.')); ?></span>
            </div>
        </li>
        <li>
            <div class="checkout-link">
                <a href="<?php echo e(route('cart.index')); ?>">Sepeti Görüntüle</a>
                <a class="red-color" href="">Onaya Gönder</a>
            </div>
        </li>
    <?php else: ?>
        <li>
            <p class="text-center">Sepetiniz boş.</p>
        </li>
    <?php endif; ?>
</ul>
<?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/partials/minicart.blade.php ENDPATH**/ ?>