<?php $__env->startSection('content'); ?>

    <main>

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg" data-background="/frontend/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2>Taksit Durumu</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home.frontend.index')); ?>">Anasayfa</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Taksit Durumu</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="shop-cart-area wishlist-area pt-100 pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="table-responsive-xl">
                            <table class="table mb-0">
                                <thead>
                                <tr>
                                    <th scope="col">Taksit</th>
                                    <th scope="col">Ödeme Tarihi</th>
                                    <th scope="col">Ödenme Tarihi</th>
                                    <th scope="col">Taksit Tutarı</th>
                                    <th scope="col">Durum</th>
                                    <th scope="col">Aksiyon</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="product-kullanici">
                                                <?php echo e($installment->taksit_no); ?>

                                            </td>
                                            <td class="product-odenen">
                                                <?php echo e($installment->due_date); ?>

                                            </td>
                                            <td class="product-gelecek">
                                                <?php echo e($installment->created_at == $installment->updated_at ? 'Henüz Ödenmedi' : $installment->updated_at); ?>

                                            </td>
                                            <td>
                                                ₺<?php echo e(number_format($installment->amount, 2, ',', '.')); ?>

                                            </td>
                                            <td class="product-durum">
                                                <?php if($installment->status == 0): ?>
                                                    <button class="btn btn-warning" style="background-color: #DC3545">Ödenmedi</button>
                                                <?php elseif($installment->status == 1): ?>
                                                    <button class="btn btn-success">Ödendi</button>
                                                <?php elseif($installment->status == 2): ?>
                                                    <button class="btn btn-info" style="background-color: #FFC107">Ödeme Günü Geçmiş</button>
                                                <?php endif; ?>
                                            </td>
                                            <!-- Ödeme Yap Butonu -->
                                            <?php if($installment->status == 1): ?>
                                                <td></td>
                                            <?php else: ?>
                                                <td class="product-aksiyon">
                                                    <button type="button" class="btn btn-success" style="background-color: #007BFF; color: white;" data-toggle="modal" data-target="#paymentModal">
                                                        Ödeme Yap
                                                    </button>
                                                </td>
                                            <?php endif; ?>


                                            <!-- Ödeme Bilgileri Modal -->
                                            <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 id="paymentModalLabel">Ödeme Bilgileri</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p><strong>IBAN:</strong> 1111111111111</p>
                                                            <p><strong>Alıcı Adı Soyadı:</strong> Aytekin Aytekin</p>
                                                            <p class="text-danger"><strong>Ödeme yapıldıktan sonra lütfen dekontu WhatsApp’tan gönderiniz.</strong></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="shop-cart-bottom mt-20">
                            <div class="row">
                                <div class="col-md-7">
                                </div>
                                <div class="col-md-5">
                                    <div class="continue-shopping">
                                        <a href="<?php echo e(route('product.filter', 'kampanya')); ?>" class="btn">Alışverişe Devam Et</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/installment/view.blade.php ENDPATH**/ ?>