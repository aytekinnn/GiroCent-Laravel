<?php $__env->startSection('content'); ?>

    <main>

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg" data-background="/frontend/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2>Siparişlerim</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home.frontend.index')); ?>">Anasayfa</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Siparişlerim</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- shop-cart-area -->
        <section class="shop-cart-area wishlist-area pt-100 pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="table-responsive-xl">
                            <table class="table mb-0">
                                <thead>
                                <tr>
                                    <th class="product-thumbnail"></th>
                                    <th class="product-name">Ürün Adı</th>
                                    <th class="product-status">Ürün Durumu</th>
                                    <th class="product-subtotal">İNDİRİMLİ FİYAT</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="product-thumbnail" style="width: 200px">
                                                <a href="<?php echo e(route('product.detail', $product->slug)); ?>">
                                                    <img width="100%" src="/images/products/<?php echo e($product->image); ?>" alt="">
                                                </a>
                                            </td>
                                            <td class="product-name">
                                                <h4>
                                                    <a href="<?php echo e(route('product.detail', $product->slug)); ?>">
                                                        <?php echo e($product->name); ?>

                                                    </a>
                                                </h4>
                                            </td>
                                            <td class="product-status">
                                                <?php if($order->status == 1): ?>
                                                    <button class="btn btn-info" style="background-color: #FFC107">Onay Bekliyor</button>
                                                <?php elseif($order->status == 2): ?>
                                                    <button class="btn btn-success">Siparişiniz Onaylandı</button>
                                                <?php elseif($order->status == 3): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #DC3545">Siparişiniz Reddedildi</button>
                                                <?php elseif($order->status == 4): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #FFC107">Kısmen Onaylandı</button>
                                                <?php elseif($order->status == 5): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #FFC107">Limit Açıldı</button>
                                                <?php elseif($order->status == 6): ?>
                                                    <button class="btn btn-success">Sözleşme Hazırlanıyor</button>
                                                <?php elseif($order->status == 7): ?>
                                                    <button class="btn btn-success">Sözleşme Kargoda</button>
                                                <?php elseif($order->status == 8): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #FFC107">Ürün Hazırlanıyor</button>
                                                <?php elseif($order->status == 9): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #FFC107">Ürün Kargoda</button>
                                                <?php elseif($order->status == 10): ?>
                                                    <button class="btn btn-warning-300" style="background-color: #FFC107">Sözleşme İnceleniyor</button>
                                                <?php endif; ?>
                                            </td>
                                            <td class="product-subtotal">
                                                <span>
                                                    ₺<?php echo e(number_format($product->campaigns->first()->new_price ?? $product->price, 2, ',', '.')); ?>

                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="shop-cart-bottom mt-20">
                            <div class="row">
                                <div class="col-md-7">
                                </div>
                                <div class="col-md-5">
                                    <div class="continue-shopping">
                                        <a href="<?php echo e(route('product.filter', 'kampanya')); ?>" class="btn">Alışverişe Devam Et</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- shop-cart-area-end -->

        <!-- core-features -->
        <section class="core-features-area core-features-style-two">
            <div class="container">
                <div class="core-features-border">
                    <div class="row justify-content-center">
                        <div class="col-xl-3 col-lg-4 col-sm-6">
                            <div class="core-features-item mb-50">
                                <div class="core-features-icon">
                                    <img src="img/icon/core_features01.png" alt="">
                                </div>
                                <div class="core-features-content">
                                    <h6>Free Shipping On Over $ 50</h6>
                                    <span>Agricultural mean crops livestock</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-6">
                            <div class="core-features-item mb-50">
                                <div class="core-features-icon">
                                    <img src="img/icon/core_features02.png" alt="">
                                </div>
                                <div class="core-features-content">
                                    <h6>Membership Discount</h6>
                                    <span>Only MemberAgricultural livestock</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-6">
                            <div class="core-features-item mb-50">
                                <div class="core-features-icon">
                                    <img src="img/icon/core_features03.png" alt="">
                                </div>
                                <div class="core-features-content">
                                    <h6>Money Return</h6>
                                    <span>30 days money back guarantee</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-sm-6">
                            <div class="core-features-item mb-50">
                                <div class="core-features-icon">
                                    <img src="img/icon/core_features04.png" alt="">
                                </div>
                                <div class="core-features-content">
                                    <h6>Online Support</h6>
                                    <span>30 days money back guarantee</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- core-features-end -->




    </main>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/default/order.blade.php ENDPATH**/ ?>