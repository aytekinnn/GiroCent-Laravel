<?php $__env->startSection('content'); ?>
    <style>
        .data-price.selected {
            box-shadow: 0px 0px 10px #FE6001;
            background-color: #FE6001;
            color: white;
            border-radius: 5px;
        }

    </style>
    <main>

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg" data-background="/frontend/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2><?php echo e($product->name); ?></h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home.frontend.index')); ?>">Anasayfa</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- shop-details-area -->
        <section class="shop-details-area pt-100 pb-100">
            <div class="container">
                <div class="row mb-95">
                    <div class="col-xl-7 col-lg-6">
                        <div class="shop-details-nav-wrap">
                            <div class="shop-details-nav">
                                <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="shop-nav-item">
                                        <img src="/images/gallery/<?php echo e($gallery->galeri_yol); ?>" alt="">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="shop-details-img-wrap">
                            <div class="shop-details-active">
                                <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="shop-nav-item">
                                        <img width="100%" src="/images/gallery/<?php echo e($gallery->galeri_yol); ?>" alt="">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5 col-lg-6">
                        <div class="shop-details-content">
                           <span class="stock-info">
                                <?php if($product->stock == 0): ?>
                                   <?php switch($product->stok_dis_durum):
                                       case (0): ?>
                                           0-2 Gün İçinde Stok Aktif
                                           <?php break; ?>
                                       <?php case (1): ?>
                                           Ön Sipariş
                                           <?php break; ?>
                                       <?php case (3): ?>
                                           Stokta Bulunmuyor
                                           <?php break; ?>
                                       <?php default: ?>
                                           Stokta Var
                                   <?php endswitch; ?>
                               <?php else: ?>
                                   Stokta Var
                               <?php endif; ?>
                            </span>

                            <h2><?php echo e($product->name); ?></h2>











                            <div class="shop-details-price">
                                <h2 id="product_price">
                                    ₺<?php echo e(number_format($product->campaigns->first() ? $product->campaigns->first()->new_price : $product->price, 2, ',', '.')); ?>

                                    <?php if($product->campaigns->first() && $product->campaigns->first()->id): ?>
                                        <del>₺<?php echo e(number_format($product->price, 2, ',', '.')); ?></del>
                                    <?php endif; ?>
                                </h2>
                            </div>

                            <p><?php echo e($product->description); ?></p>

                            <?php if($product->groupedExtraFeatures && count($product->groupedExtraFeatures) > 0): ?>
                                <div class="product-details-size mb-40">
                                    <ul>
                                        <?php $__currentLoopData = $product->groupedExtraFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featureId => $extraFeatureGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($extraFeatureGroup->isNotEmpty()): ?> 
                                            <li>
                                                <strong><?php echo e(optional($extraFeatureGroup->first()['feature'])->name); ?></strong>
                                                <ul>
                                                    <?php $__currentLoopData = $extraFeatureGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a class="data-price" data-id="<?php echo e($extraFeature['id']); ?>" data-price="<?php echo e($extraFeature['price'] ?? 0); ?>" href="#">
                                                                <?php echo e($extraFeature['content'] ?? 'Bilinmeyen İçerik'); ?>

                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>



                            <div class="perched-info">
                                <a href="#" class="btn add-card-btn add-to-cart"
                                   data-id="<?php echo e($product->id); ?>"
                                   data-name="<?php echo e($product->name); ?>"
                                   data-price="<?php echo e($product->campaigns->first() ? $product->campaigns->first()->new_price : $product->price); ?>"
                                   data-extra_feature_id=""
                                   data-image="/images/products/<?php echo e($product->image); ?>">SEPETE EKLE</a>
                            </div>
                            <div class="shop-details-bottom">
                                <h5><a href="#"><i class="far fa-heart"></i> Favorilere Ekle</a></h5>
                                <ul>
                                    <li>
                                        <span>KATEGORİLER :</span>
                                        <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('product.filter', $category->slug)); ?>"><?php echo e($category->name); ?>,</a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="product-desc-wrap mb-100">
                            <ul class="nav nav-tabs mb-25" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="details-tab" data-toggle="tab" href="#details"
                                       role="tab" aria-controls="details"
                                       aria-selected="true">Ürün Detay</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="details" role="tabpanel"
                                     aria-labelledby="details-tab">
                                    <div class="product-desc-content">
                                        <h4 class="title">Ürün Detay</h4>
                                        <div class="row">
                                            <div class="col-xl-3 col-md-4">
                                                <div class="product-desc-img">
                                                    <img src="/images/products/<?php echo e($product->image); ?>" alt="">
                                                </div>
                                            </div>
                                            <div class="col-xl-9 col-md-8">
                                                <h5 class="small-title"><?php echo e($product->name); ?></h5>
                                                <p><?php echo e($product->description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="shop-details-add mb-95">
                            <a href="#"><img src="/frontend/img/product/shop_details_add.jpg" alt=""></a>
                        </div>
                        <div class="related-product-wrap pb-95">
                            <div class="deal-day-top">
                                <div class="deal-day-title">
                                    <h4 class="title">Benzer Ürünler</h4>
                                </div>
                                <div class="related-slider-nav">
                                    <div class="slider-nav"></div>
                                </div>
                            </div>
                            <div class="row related-product-active">
                                <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-3">
                                        <div class="exclusive-item exclusive-item-three text-center">
                                            <div class="exclusive-item-thumb">
                                                <a href="<?php echo e(route('product.detail', $similarProduct->slug)); ?>">
                                                    <img src="/images/products/<?php echo e($similarProduct->image); ?>" alt="">
                                                    <img class="overlay-product-thumb" src="/images/products/<?php echo e($similarProduct->image); ?>" alt="">
                                                </a>
                                                <ul class="action">
                                                    <li><a href="#"><i class="flaticon-supermarket"></i></a></li>
                                                </ul>
                                            </div>
                                            <div class="exclusive-item-content">
                                                <h5><a href="<?php echo e(route('product.detail', $similarProduct->slug)); ?>"><?php echo e($similarProduct->name); ?></a></h5>
                                                <div class="exclusive--item--price">
                                                    <?php if($similarProduct->campaigns->first() && $similarProduct->campaigns->first()->id): ?>
                                                        <del class="old-price">
                                                            ₺<?php echo e(number_format($similarProduct->price, 2, ',', '.')); ?></del>
                                                        <span class="new-price">₺<?php echo e(number_format($similarProduct->campaigns->first()->new_price, 2, ',', '.')); ?></span>
                                                    <?php else: ?>
                                                        <span class="new-price">₺<?php echo e(number_format($similarProduct->price, 2, ',', '.')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>








































































































































                    </div>
                </div>
            </div>
        </section>
        <!-- shop-details-area-end -->

        <!-- limited-offer-area -->
        <section class="limited-offer-area" data-background="/frontend/img/bg/limited_offer_bg.jpg">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-xl-9 col-lg-8 col-md-7">
                        <div class="limited-offer-left">
                            <div class="limited-offer-title">
                                <span class="sub-title">özel teklif</span>
                                <h2 class="title"><?php echo e(\Illuminate\Support\Str::limit($kampanya->product->name, 70)); ?></h2>
                            </div>
                            <div class="limited-offer-disc">
                                <img src="/frontend/img/images/limited_offer_discount.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-5">
                        <div class="limited-offer-action">
                            <a href="<?php echo e(route('product.detail', $kampanya->product->slug)); ?>" class="btn">sınırlı süreli teklif</a>
                            <div class="amount-info">
                                <span class="amount">₺<?php echo e(number_format($kampanya->new_price, 2, ',', '.')); ?></span>
                                <span class="off">İNDİRİM</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <h2 class="limited-overlay-title"><?php echo e($kampanya->name . ' ' . $kampanya->discount); ?><span>%</span></h2>
        </section>
        <!-- limited-offer-area-end -->


    </main>

    <script>
        $(document).ready(function () {
            let basePrice = parseFloat("<?php echo e($product->campaigns->first() ? $product->campaigns->first()->new_price : $product->price); ?>".replace(',', '.'));
            let updatedPrice = basePrice; // Güncellenmiş fiyatı saklayacak değişken
            let extraFeatures = []; // Extra özellikler dizisi

            console.log("Başlangıç fiyatı:", basePrice);

            $(".data-price").click(function (e) {
                e.preventDefault(); // Sayfa yenilenmesini önle

                let selectedPrice = parseFloat($(this).attr("data-price"));
                let selectedId = $(this).attr("data-id");
                let selectedContent = $(this).text().trim();

                console.log("Seçilen fiyat:", selectedPrice);

                if ($(this).hasClass("selected")) {
                    updatedPrice -= selectedPrice;
                    $(this).removeClass("selected");
                    // Seçilen özellik kaldırılacak, diziden çıkar
                    extraFeatures = extraFeatures.filter(feature => feature.id !== selectedId);
                    console.log("Özellik kaldırıldı, yeni fiyat:", updatedPrice);
                } else {
                    updatedPrice += selectedPrice;
                    $(this).addClass("selected");
                    // Yeni özellik dizisine ekle
                    extraFeatures.push({
                        id: selectedId,
                        content: selectedContent,
                        price: selectedPrice
                    });
                    console.log("Özellik eklendi, yeni fiyat:", updatedPrice);
                }

                // Güncellenmiş fiyatı formatlayıp yazdır
                $("#product_price").html("₺" + updatedPrice.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));

                // Sepete ekle butonunun data-price ve data-extra-feature_id özelliğini güncelle
                $(".add-to-cart").attr("data-price", updatedPrice);

                // Extra özellikleri formatla ve butona ekle
                let formattedExtraFeatures = extraFeatures.map(feature => `${feature.id},${feature.content},${feature.price}`).join("||");
                $(".add-to-cart").attr("data-extra_feature_id", formattedExtraFeatures);
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/product/detail.blade.php ENDPATH**/ ?>