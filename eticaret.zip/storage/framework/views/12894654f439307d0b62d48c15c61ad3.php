<form action="<?php echo e(Route('features.edit')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="col-12">
        <label class="form-label">Özellik Adı</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($features->name); ?>">
    </div>
    <div class="col-12">
        <label class="form-label">Üst Özellik Kategori</label>
        <select name="ust_id" class="form-select">
            <?php
                $ustCategory = \App\Models\Faetures::find($features->ust_id);
            ?>
            <option value="<?php echo e($features->ust_id ?? ''); ?>"><?php echo e($ustCategory->name ?? 'Seçili Üst Özellik Yok'); ?></option>
            <?php $__currentLoopData = $featuries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>" <?php echo e($cat->id == $ust_id ? 'selected' : ''); ?>>
                    <?php echo e($cat->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12">
        <label class="form-label">Durum</label>
        <select name="status" class="form-select">
            <option <?php echo e($features->status == "1" ? "selected" : ""); ?> value="1">Aktif</option>
            <option <?php echo e($features->status == "0" ? "selected" : ""); ?> value="0">Pasif</option>
        </select>
    </div>
    <input type="hidden" name="id" value="<?php echo e($features->id); ?>">

    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary-600 radius-8 px-20 py-11">
            Düzenle
        </button>
        <button type="button" class="btn btn-outline-warning-600 radius-8 px-20 py-11" data-bs-dismiss="modal">
            Kapat
        </button>
    </div>

</form>
<?php /**PATH C:\localhost\htdocs\eticaret\resources\views/backend/features/view.blade.php ENDPATH**/ ?>