<?php $__env->startSection('content'); ?>

    <div class="dashboard-main-body">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <h6 class="fw-semibold mb-0">Siparişler</h6>
            <ul class="d-flex align-items-center gap-2">
                <li class="fw-medium">
                    <a href="<?php echo e(Route('home.index')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                        Anasayfa
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">Siparişler</li>
            </ul>
        </div>

        <div class="card basic-data-table">
            <div class="card-body">
                <table class="table bordered-table mb-0" id="dataTable" data-page-length='10'>
                    <thead>
                    <tr>
                        
                        
                        
                        
                        
                        
                        
                        
                        <th scope="col">Adı</th>
                        <th scope="col">Sipariş Tarihi</th>
                        <th scope="col">Durum</th>
                        <th scope="col">Aksiyon</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($orders->user->name); ?>

                            </td>
                            <td>
                                <?php echo e($orders->created_at); ?>

                            </td>
                            <?php if($orders->status == 1): ?>
                                <td>
                                    <span
                                        class="bg-info-focus text-info-main px-24 py-4 rounded-pill fw-medium text-sm">Onay Bekliyor</span>
                                </td>
                            <?php elseif($orders->status == 2): ?>
                                <td>
                                    <span
                                        class="bg-success-focus text-success-main px-24 py-4 rounded-pill fw-medium text-sm">Onaylandı</span>
                                </td>
                            <?php elseif($orders->status == 3): ?>
                                <td>
                                    <span
                                        class="bg-warning-focus text-warning-main px-24 py-4 rounded-pill fw-medium text-sm">Reddedildi</span>
                                </td>
                            <?php elseif($orders->status == 4): ?>
                                <td>
                                    <span
                                        class="bg-info-focus text-info-main px-24 py-4 rounded-pill fw-medium text-sm">Kısmen Onaylandı</span>
                                </td>
                            <?php elseif($orders->status == 5): ?>
                                <td>
                                    <span
                                        class="bg-success-focus text-success-main px-24 py-4 rounded-pill fw-medium text-sm">Limit Açıldı</span>
                                </td>
                            <?php elseif($orders->status == 6): ?>
                                <td>
                                    <span
                                        class="bg-info-focus text-info-main px-24 py-4 rounded-pill fw-medium text-sm">Sözleşme Hazırlanıyor</span>
                                </td>
                            <?php elseif($orders->status == 7): ?>
                                <td>
                                    <span
                                        class="bg-success-focus text-success-main px-24 py-4 rounded-pill fw-medium text-sm">Sözleşme Kargoda</span>
                                </td>
                            <?php elseif($orders->status == 8): ?>
                                <td>
                                    <span
                                        class="bg-info-focus text-info-main px-24 py-4 rounded-pill fw-medium text-sm">Ürün Hazırlanıyor</span>
                                </td>
                            <?php elseif($orders->status == 9): ?>
                                <td>
                                    <span
                                        class="bg-success-focus text-success-main px-24 py-4 rounded-pill fw-medium text-sm">Ürün Kargoda</span>
                                </td>
                            <?php elseif($orders->status == 10): ?>
                                <td>
                                    <span
                                        class="bg-info-focus text-info-main px-24 py-4 rounded-pill fw-medium text-sm">Sözleşme İnceleniyor</span>
                                </td>
                            <?php endif; ?>
                            
                            
                            
                            <td>
                                <button type="button" data-bs-toggle="modal"
                                        data-bs-target="#add-contact-d"
                                        class="edit-button w-32-px h-32-px bg-success-focus text-success-main rounded-circle d-inline-flex align-items-center justify-content-center">
                                    <a href="<?php echo e(route('order.edit-view', $orders->id)); ?>">
                                        <iconify-icon icon="lucide:eye"></iconify-icon>
                                    </a>
                                </button>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/backend/orders/index.blade.php ENDPATH**/ ?>