<form action="<?php echo e(Route('manufacturer.edit')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="col-12">
        <label class="form-label">Üretici Adı</label>
        <input type="text" name="name" id="ureticiAdi" class="form-control" value="<?php echo e($manufacturer->name); ?>" oninput="geneSlug()">
    </div>
    <div class="col-12">
        <label class="form-label">Seo Link Url</label>
        <input type="text" name="slug" id="seoLinks" class="form-control" value="<?php echo e($manufacturer->slug); ?>">
    </div>
    <div class="col-12">
        <label class="form-label">Durum</label>
        <select name="status" class="form-select">
            <option <?php echo e($manufacturer->status=="1" ? "selected=''" : ""); ?> value="1">Aktif</option>
            <option <?php echo e($manufacturer->status=="0" ? "selected=''" : ""); ?> value="0">Pasif</option>
        </select>
    </div>
    <input type="hidden" name="id" value="<?php echo e($manufacturer->id); ?>">

    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary-600 radius-8 px-20 py-11">
            Düzenle
        </button>
        <button type="button" class="btn btn-outline-warning-600 radius-8 px-20 py-11" data-bs-dismiss="modal">
            Kapat
        </button>
    </div>
</form>

<script>

</script>
<?php /**PATH C:\localhost\htdocs\eticaret\resources\views/backend/manufacturers/view.blade.php ENDPATH**/ ?>