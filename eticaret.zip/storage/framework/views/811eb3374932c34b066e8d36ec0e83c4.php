<?php $__env->startSection('content'); ?>

    <main>

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg" data-background="/frontend/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2><?php echo e($category->name ?? 'Kampanyalar'); ?></h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home.frontend.index')); ?>">Anasayfa</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name ?? 'Kampanyalar'); ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- shop-area -->
        <div class="shop-area gray-bg pt-100 pb-100">
            <div class="custom-container-two">
                <div class="row justify-content-center">
























                    <div class="col-xl-12 col-lg-12">
                        <div class="shop-top-meta mb-40">
                            <p class="show-result"> <?php echo e(($products->currentPage() - 1) * $products->perPage() + 1); ?> -
                                <?php echo e(min($products->currentPage() * $products->perPage(), $products->total())); ?> ürün arasında <?php echo e($products->total()); ?> ürün gösteriliyor</p>
                            <div class="shop-meta-right">











                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-lg-4 col-md-3 col-sm-4">
                                    <div class="exclusive-item exclusive-item-three text-center mb-50">
                                        <div class="exclusive-item-thumb">
                                            <a href="<?php echo e(route('product.detail', $product->slug)); ?>">
                                                <img src="/images/products/<?php echo e($product->image); ?>" alt="">
                                                <img class="overlay-product-thumb"
                                                     src="/images/products/<?php echo e($product->image); ?>" alt="">
                                            </a>
                                            <ul class="action">
                                                <li>
                                                    <a class="add-to-cart"
                                                        data-id="<?php echo e($product->id); ?>"
                                                        data-name="<?php echo e($product->name); ?>"
                                                        data-price="<?php echo e($product->campaigns->first() ? $product->campaigns->first()->new_price : $product->price); ?>"
                                                        data-campaigns="<?php echo e($product->campaigns->first() ? $product->campaigns->first()->id : 0); ?>"
                                                        data-image="/images/products/<?php echo e($product->image); ?>">
                                                        <i class="flaticon-supermarket"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="exclusive-item-content">
                                            <h5><a href="<?php echo e(route('product.detail', $product->slug)); ?>"><?php echo e($product->name); ?></a></h5>
                                            <div class="exclusive--item--price">
                                                <?php if($product->campaigns->first() && $product->campaigns->first()->id): ?>
                                                    <del class="old-price">
                                                        ₺<?php echo e(number_format($product->price, 2, ',', '.')); ?></del>
                                                    <span
                                                        class="new-price">₺<?php echo e(number_format($product->campaigns->first()->new_price, 2, ',', '.')); ?></span>
                                                <?php else: ?>
                                                    <span
                                                        class="new-price">₺<?php echo e(number_format($product->price, 2, ',', '.')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="pagination-wrap">
                                    <?php echo $products->links('frontend.default.pagination'); ?>

                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- shop-area-end -->

    </main>

    <script>
        document.getElementById('sortOption').addEventListener('change', function () {
            requestAnimationFrame(function() {
                document.getElementById('filterForm').submit(); // Formu gönder
            });
        });

        $(document).ready(function () {
            // URL'den mevcut fiyat değerlerini al
            let urlParams = new URLSearchParams(window.location.search);
            let minPrice = urlParams.get("price_min") ? parseInt(urlParams.get("price_min")) : 2500;
            let maxPrice = urlParams.get("price_max") ? parseInt(urlParams.get("price_max")) : 50000;

            // jQuery UI Slider'ı başlat ve değerleri ayarla
            $("#slider-range").slider({
                range: true,
                min: 2000,
                max: 150000,
                values: [minPrice, maxPrice],
                slide: function (event, ui) {
                    $("#amount").val(ui.values[0] + " - " + ui.values[1]);
                    $("#price_min").val(ui.values[0]);
                    $("#price_max").val(ui.values[1]);
                }
            });

            // Seçili fiyat aralığını inputlara yaz
            $("#amount").val(minPrice + " - " + maxPrice);
            $("#price_min").val(minPrice);
            $("#price_max").val(maxPrice);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/product/filter.blade.php ENDPATH**/ ?>