<?php $__env->startSection('content'); ?>

    <main>

    <!-- breadcrumb-area -->
    <section class="breadcrumb-area breadcrumb-bg" data-background="/frontend/img/bg/breadcrumb_bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content text-center">
                        <h2>Üye Ol</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home.frontend.index')); ?>">Anasayfa</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Üye Ol</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->

    <!-- my-account-area -->
    <section class="my-account-area pattern-bg pt-100 pb-100" data-background="/frontend/img/bg/pattern_bg.jpg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-10">
                    <div class="login-page-title">
                        <h2 class="title"><span>Üye</span> Ol</h2>
                    </div>
                    <div class="my-account-bg" data-background="/frontend/img/bg/my_account_bg.png">
                        <div class="my-account-content">
                            <form action="<?php echo e(route('register.post')); ?>" method="post" enctype="multipart/form-data" class="login-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-grp">
                                    <label for="">PROFİL RESMİNİZ</label>
                                    <input name="image" type="file" id="">
                                </div>
                                <div class="form-grp">
                                    <label for="uea">İSİM SOYİSİM <span>*</span></label>
                                    <input name="name" type="text" id="uea">
                                </div>
                                <div class="form-grp">
                                    <label for="uea">TELEFON NUMARANIZ <span>*</span></label>
                                    <input name="phone" type="tel" id="uea">
                                </div>
                                <div class="form-grp">
                                    <label for="uea">MAİL ADRESİNİZ <span>*</span></label>
                                    <input name="email" type="text" id="uea">
                                </div>
                                <div class="form-grp">
                                    <label for="password">ŞİFRE <span>*</span></label>
                                    <input name="password" type="password" id="password">
                                    <i class="far fa-eye"></i>
                                </div>
                                <div class="form-grp">
                                    <label for="password">ŞİFRE TEKRAR<span>*</span></label>
                                    <input name="password1" type="password" id="password">
                                    <i class="far fa-eye"></i>
                                </div>
                                <div class="form-grp-btn">
                                    <a href="#" class="btn"><button style="background-color: transparent;color: white; border: 0px;text-transform: uppercase;" type="submit">Üye Ol</button></a>
                                    <a href="<?php echo e(route('login.front')); ?>" class="btn">Giriş Yap</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- my-account-area-end -->

    <!-- limited-offer-area -->
    <section class="limited-offer-area" data-background="/frontend/img/bg/limited_offer_bg.jpg">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-5 col-lg-6 col-md-7">
                    <div class="limited-offer-left">
                        <div class="limited-offer-title">
                            <span class="sub-title">exclusive offer</span>
                            <h2 class="title">Smart Watch Bracelet</h2>
                        </div>
                        <div class="limited-offer-disc">
                            <img src="img/images/limited_offer_discount.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-5">
                    <div class="limited-offer-action">
                        <a href="#" class="btn">limited time offer</a>
                        <div class="amount-info">
                            <span class="upto">UPTO</span>
                            <span class="amount">$ 50.00</span>
                            <span class="off">OFF</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h2 class="limited-overlay-title">Vanam Top Sale 35<span>%</span></h2>
        <div class="limited-overlay-img"><img src="/frontend/img/images/limited_offer_img.png" alt=""></div>
    </section>
    <!-- limited-offer-area-end -->

</main>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\eticaret\resources\views/frontend/default/register.blade.php ENDPATH**/ ?>